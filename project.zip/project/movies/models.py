from django.db import models


"""
Possible data types on models:

char (strings)
Int (int)
Float (decimal point numbers)
Boolean (true/false)

"""
# Create your models here.
# CRUD


class Genre(models.Model):
    name = models.CharField(max_length=255)

    def __str__(self):
        return self.name


class Movie(models.Model):
    title = models.CharField(max_length=255)
    release_year = models.IntegerField()
    in_stock = models.IntegerField()
    price = models.FloatField()
    genre = models.ForeignKey(Genre, on_delete=models.CASCADE)
    director = models.CharField(max_length=255)

    def __str__(self):
        return self.title


class Series(models.Model):
    class Meta:
        verbose_name_plural = "Series"

    title = models.CharField(max_length=255)
    season = models.IntegerField()
    show = models.IntegerField()
    genre = models.ForeignKey(Genre, on_delete=models.CASCADE)
    director = models.CharField(max_length=255)

    def __str__(self):
        return self.title
