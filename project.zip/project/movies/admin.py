from django.contrib import admin

from .models import Genre, Movie, Series


# Register your models here.

class GenreAdmin(admin.ModelAdmin):
    list_display = ('id', 'name')


class MovieAdmin(admin.ModelAdmin):
    # which properties will be shown on page
    list_display = ('id', 'title', 'in_stock', 'price')
    #exclude = ('in_stock', 'price')
    fields = ('genre', 'title', 'director', 'in_stock', 'price')


class SeriesAdmin(admin.ModelAdmin):
    list_display = ('id', 'title')
    fields = ('genre', 'title', 'season', 'show', 'director')


admin.site.register(Genre)
admin.site.register(Movie, MovieAdmin)
admin.site.register(Series, SeriesAdmin)


# class SeriesAdmin(admin.ModelAdmin):
# props will be listed on the display table
# list_display = ('id', 'title', 'in_stock', 'price')
#exclude = ('in_stock', 'price')
#fields = ('genre', 'title', 'director',  'in_stock', 'price')


"""
Task : new model
Series | user | Account | Employee

- create the model
** perform migrations
    - python manage.py makemigrations
    - python manage.py migrate

- register the model
- create/register the admin class




"""
